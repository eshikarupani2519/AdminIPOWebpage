import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { IpoService } from 'src/app/services/ipo.service';
@Component({
  selector: 'app-upcoming-ipo-screen',
  templateUrl: './upcoming-ipo-screen.component.html',
  styleUrls: ['./upcoming-ipo-screen.component.css']
})
export class UpcomingIpoScreenComponent {
  constructor(private ipoService:IpoService,private router:Router){}
  ipos: any[] = [];
  loggedInUser:string='';
  activePage!:number;
  currentPage: number = 1;
itemsPerPage: number = 6;
totalPages: number = 0;
totalPagesArray: number[] = [];
  paginatedIPOs:any=[]

ngOnInit() {
  this.ipoService.getAllIPOs().subscribe({
    next: (ipos) => {
      this.ipos = ipos as any[];
      console.log(this.ipos)
      this.updatePagination();
    },
    error: (err) => {
      console.error(err);
    }
  });
  
}

goToRegisterIpo(){
this.router.navigate(['register-ipo-details'])
}
updatePagination() {
  console.log('update pagination')
  this.totalPages = Math.ceil(this.ipos.length / this.itemsPerPage);
  this.totalPagesArray = Array.from({ length: this.totalPages }, (_, i) => i + 1);
  const startIndex = (this.currentPage - 1) * this.itemsPerPage;
  const endIndex = startIndex + this.itemsPerPage;
  if(this.itemsPerPage<this.ipos.length)
  {
 this.paginatedIPOs = this.ipos.slice(startIndex, endIndex);
 console.log('no pagination needed')
  }
  else{
     this.paginatedIPOs = this.ipos;
     console.log('insertion done')
  }
 
}

goToPage(event: Event, page: number) {
  event.preventDefault();
  this.currentPage = page;
  this.updatePagination();
}

goToPreviousPage(event: Event) {
  event.preventDefault();
  if (this.currentPage > 1) {
    this.currentPage--;
    this.updatePagination();
  }
}

goToNextPage(event: Event) {
  event.preventDefault();
  if (this.currentPage < this.totalPages) {
    this.currentPage++;
    this.updatePagination();
  }
}
editIPO(id: number) {
  this.router.navigate(['/register-ipo-details'], { queryParams: { id: id } });

}

selectedIPO: any;

viewDetails(ipo: any) {
  this.selectedIPO = ipo;
}

}
