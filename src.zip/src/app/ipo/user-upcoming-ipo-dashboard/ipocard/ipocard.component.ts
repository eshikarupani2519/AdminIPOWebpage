import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-ipocard',
  templateUrl: './ipocard.component.html',
  styleUrls: ['./ipocard.component.css']
})
export class IpocardComponent {
@Input()
ipo:any

downloadUrl = `http://localhost:5000/api/ipos/1/download`;

}
