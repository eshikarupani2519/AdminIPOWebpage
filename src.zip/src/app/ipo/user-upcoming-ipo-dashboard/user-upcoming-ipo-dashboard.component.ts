import { Component } from '@angular/core';

@Component({
  selector: 'app-user-upcoming-ipo-dashboard',
  templateUrl: './user-upcoming-ipo-dashboard.component.html',
  styleUrls: ['./user-upcoming-ipo-dashboard.component.css']
})
export class UserUpcomingIpoDashboardComponent {

}
