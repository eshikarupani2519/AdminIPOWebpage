import { Component } from '@angular/core';

@Component({
  selector: 'app-page-body',
  templateUrl: './page-body.component.html',
  styleUrls: ['./page-body.component.css']
})
export class PageBodyComponent {
IPOs=[
  {
    companyLogo:"../../assets/nova-logo.png",
    companyName:"Nova Agritech Ltd.",
    priceBand:"Rs. 39 - 41",
    open:"2024-01-22",
    close:"2024-01-24",
    issueSize:"143.81 Cr.",
    issueType:"Book Built",
    listingDate:"2024-01-30"
  },
   {
    companyLogo:"../../assets/nova-logo.png",
    companyName:"Nova Agritech Ltd.",
    priceBand:"Rs. 39 - 41",
    open:"2024-01-22",
    close:"2024-01-24",
    issueSize:"143.81 Cr.",
    issueType:"Book Built",
    listingDate:"2024-01-30"
  },
   {
    companyLogo:"../../assets/nova-logo.png",
    companyName:"Nova Agritech Ltd.",
    priceBand:"Rs. 39 - 41",
    open:"2024-01-22",
    close:"2024-01-24",
    issueSize:"143.81 Cr.",
    issueType:"Book Built",
    listingDate:"2024-01-30"
  },
   {
    companyLogo:"../../assets/nova-logo.png",
    companyName:"Nova Agritech Ltd.",
    priceBand:"Rs. 39 - 41",
    open:"2024-01-22",
    close:"2024-01-24",
    issueSize:"143.81 Cr.",
    issueType:"Book Built",
    listingDate:"2024-01-30"
  },
   {
    companyLogo:"../../assets/nova-logo.png",
    companyName:"Nova Agritech Ltd.",
    priceBand:"Rs. 39 - 41",
    open:"2024-01-22",
    close:"2024-01-24",
    issueSize:"143.81 Cr.",
    issueType:"Book Built",
    listingDate:"2024-01-30"
  },
   {
    companyLogo:"../../assets/nova-logo.png",
    companyName:"Nova Agritech Ltd.",
    priceBand:"Rs. 39 - 41",
    open:"2024-01-22",
    close:"2024-01-24",
    issueSize:"143.81 Cr.",
    issueType:"Book Built",
    listingDate:"2024-01-30"
  },
   {
    companyLogo:"../../assets/nova-logo.png",
    companyName:"Nova Agritech Ltd.",
    priceBand:"Rs. 39 - 41",
    open:"2024-01-22",
    close:"2024-01-24",
    issueSize:"143.81 Cr.",
    issueType:"Book Built",
    listingDate:"2024-01-30"
  },
   {
    companyLogo:"../../assets/nova-logo.png",
    companyName:"Nova Agritech Ltd.",
    priceBand:"Rs. 39 - 41",
    open:"2024-01-22",
    close:"2024-01-24",
    issueSize:"143.81 Cr.",
    issueType:"Book Built",
    listingDate:"2024-01-30"
  },
   {
    companyLogo:"../../assets/nova-logo.png",
    companyName:"Nova Agritech Ltd.",
    priceBand:"Rs. 39 - 41",
    open:"2024-01-22",
    close:"2024-01-24",
    issueSize:"143.81 Cr.",
    issueType:"Book Built",
    listingDate:"2024-01-30"
  },
   {
    companyLogo:"../../assets/nova-logo.png",
    companyName:"Nova Agritech Ltd.",
    priceBand:"Rs. 39 - 41",
    open:"2024-01-22",
    close:"2024-01-24",
    issueSize:"143.81 Cr.",
    issueType:"Book Built",
    listingDate:"2024-01-30"
  },
   {
    companyLogo:"../../assets/nova-logo.png",
    companyName:"Nova Agritech Ltd.",
    priceBand:"Rs. 39 - 41",
    open:"2024-01-22",
    close:"2024-01-24",
    issueSize:"143.81 Cr.",
    issueType:"Book Built",
    listingDate:"2024-01-30"
  },
   {
    companyLogo:"../../assets/nova-logo.png",
    companyName:"Nova Agritech Ltd.",
    priceBand:"Rs. 39 - 41",
    open:"2024-01-22",
    close:"2024-01-24",
    issueSize:"143.81 Cr.",
    issueType:"Book Built",
    listingDate:"2024-01-30"
  }
]
}
